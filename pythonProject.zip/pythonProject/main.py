import math
# Napisać zestaw funkcji pozwalające na obliczenie: objętości, masy, pola powierzchni:
# a) kuli (10%)
# b) czworościanu foremnego (10%)
# c) elispoidy (25%) *
# d) ostrosłupa prostego o podstawie prostokątnej (10%)
# e) stożka (10%)
# f) walca (10%)
# Program powinien wyświetlając wszystkie możliwe bryły, następnie poprosić użytkownika o
# dokonanie wyboru jednej z nich. Po dokonaniu wyboru program powinien wyświetlić listę właściwości
# które wylicza (objętość, masa, pole powierzchni). Pod dokonaniu wyboru użytkownik podaje potrzebne
# parametry a następnie wyświetla wynik wybranej operacji dla wybranej bryły. Program powinien
# posiadać zabezpieczenie przed podaniem wartości niedozwolonych (np. liczb ujemnych) i informować
# o tym fakcie użytkownika w poprzez wyświetlenie odpowiedniego komunikatu (25%). Przykład
# mechanizmu, który pozwala zabezpieczyć przed podaniem liczby ujemnej oraz ciągu znaków znajduje
# się poniżej**. Wartości procentowe oznaczają możliwą do zdobycia część oceny końcowej z zadania
# domowego.
print('Wybierz bryłę podając jej numer')
print('1. Kula')
print('2. Czworościan foremny')
print('3. Elipsoida')
print('4. Ostrosłup prosty o podstawie prostokątnej')
print('5. Stożek')
print('6. Walec')
figura = int(input('Podaj numer bryły: '))

def wybrana_figura(figura):
    match figura:
        case 1:
            return wybierz_operacje(1)
        case 2:
            return wybierz_operacje(2)
        case 3:
            return wybierz_operacje(3)
        case 4:
            return wybierz_operacje(4)
        case 5:
            return wybierz_operacje(5)
        case 6:
            return wybierz_operacje(6)

def wybierz_operacje(figura):
    print("Wybierz którą wartość chcesz wyliczyć")
    print("1. Objętność")
    print("2. Masę")
    print("3. Polę powierzchni")
    operacja = int(input('Podaj numer bryły: '))
    return rezultat(figura, operacja)

def rezultat(figura, operacja):
    match figura:
        case 1:
            return kula(operacja)
        case 2:
            return czworoscian_foremny(operacja)

def kula(operacja):
    r = float(input('Podaj średnicę kuli: '))
    match operacja:
        case 1:
            print((4/3)*math.pi*r**3)
            return (4/3)*math.pi*r**3
        case 2:
            gestosc = float(input('Podaj gęstość kuli: '))
            objetosc = (4/3)*math.pi*r**3
            print(gestosc*objetosc)
            return gestosc*objetosc
        case 3:
            print(4*math.pi*r**2)
            return print(4*math.pi*r**2)

def czworoscian_foremny(operacja):
    a = float(input('Podaj długość boku czworościanu foremnego: '))
    match operacja:
        case 1:
            print((1/12)*a**3*math.sqrt(2))
            return (1/12)*a**3*math.sqrt(2)
        case 2:
            gestosc = float(input('Podaj gęstość czworoscianu foremnego: '))
            objetosc = (1/12)*a**3*math.sqrt(2)
            print(gestosc*objetosc)
            return gestosc*objetosc
        case 3:
            print(math.sqrt(3)*a**2)
            return print(math.sqrt(3)*a**2)

def elipsoida(operacja):
    a = float(input('Podaj długość pierwszej półosi elipsoidy: '))
    b = float(input('POdaj długość drugiej półosi elipsoidy: '))
    match operacja:
        case 1:
            print((4/3)*math.pi*a*b**2)
            return (4/3)*math.pi*a*b**2
        case 2:
            gestosc = float(input('Podaj gęstość elipsoidy: '))
            objetosc = ((4/3)*math.pi*a*b**2)
            print(gestosc*objetosc)
            return gestosc*objetosc
        case 3:
wybrana_figura(figura)